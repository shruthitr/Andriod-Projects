

package edu.uic.moviehub.model;

/**
 * Gallery model class.
 * Used in gallery view.
 */
public class GalleryModel {
    private String filePath;

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }


}
