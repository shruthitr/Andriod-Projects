

package edu.uic.moviehub.helper;

/**
 * Constants that indicates the scroll state of the Scrollable widgets.
 */
public enum ScrollState {


    STOP,

    UP,

    DOWN,
}