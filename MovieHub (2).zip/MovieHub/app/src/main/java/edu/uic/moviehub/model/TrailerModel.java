

package edu.uic.moviehub.model;

/**
 * Trailer model class.
 * Used in trailer view.
 */
public class TrailerModel {
    private String filePath;

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }


}
