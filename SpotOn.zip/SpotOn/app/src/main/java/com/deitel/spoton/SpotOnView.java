package com.deitel.spoton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.Queue;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SpotOnView extends View
{

    private int spotsTouched; // number of spots touched
    private long remainingTime; // remaining time
    private long timeLimitForLevel = 60000;
    private int currentLevel = 1;
    private int level; // current level
    private int viewWidth; // stores the width of this View
    private int viewHeight; // stores the height of this view
    private long animationTime; // how long each spot remains on the screen
    private boolean gameOver; // whether the game has ended
    private boolean gamePaused; // whether the game has ended
    private boolean dialogDisplayed; // whether the game has ended
    private boolean allSpotsTouched=false;

    // collections of spots (ImageViews) and Animators
    private final Queue<ImageView> spots =
            new ConcurrentLinkedQueue<ImageView>();
    private final Queue<Animator> animators =
            new ConcurrentLinkedQueue<Animator>();

    private TextView remainingTimeTextView; // displays remaining time
    private TextView levelTextView; // displays current level
    private RelativeLayout relativeLayout; // displays spots
    private Resources resources; // used to load resources
    private LayoutInflater layoutInflater; // used to inflate GUIs

    // time in milliseconds for spot and touched spot animations
    private static final Random random = new Random(); // for random coordinates
    private static final int SPOT_DIAMETER = 100; // initial spot size
    private static final float SCALE_X = 0.5f; // end animation x scale
    private static final float SCALE_Y = 0.5f; // end animation y scale
    private static final int NUMBER_OF_SPOTS = 10; // initial # of spots
    private static final int SPOT_DELAY = 200; // delay in milliseconds
    private static final int MAX_LEVEL = 5; // spots to reach new level
    private Handler spotHandler; // adds new spots to the game
    private static final int ONE_SOUND_ID = 1;
    private static final int TWO_SOUND_ID = 2;
    private static final int THREE_SOUND_ID = 3;
    private static final int FOUR_SOUND_ID = 4;
    private static final int FIVE_SOUND_ID = 5;
    private static final int SIX_SOUND_ID = 6;
    private static final int SEVEN_SOUND_ID = 7;
    private static final int EIGHT_SOUND_ID = 8;
    private static final int NINE_SOUND_ID = 9;
    private static final int TEN_SOUND_ID = 10;
    private static final int ELEVEN_SOUND_ID = 11;
    private static final int TWELVE_SOUND_ID = 12;
    private static final int THIRTEEN_SOUND_ID = 13;
    private static final int FOURTEEN_SOUND_ID = 14;
    private static final int FIFTEEN_SOUND_ID = 15;
    private static final int SIXTEEN_SOUND_ID = 16;
    private static final int SEVENTEEN_SOUND_ID = 17;
    private static final int EIGHTEEN_SOUND_ID = 18;
    private static final int NINETEEN_SOUND_ID = 19;
    private static final int TWENTY_SOUND_ID = 20;
    private static final int TWENTYONE_SOUND_ID = 21;
    private static final int TWENTYTWO_SOUND_ID = 22;
    private static final int TWENTYTHREE_SOUND_ID = 23;
    private static final int TWENTYFOUR_SOUND_ID = 24;
    private static final int TWENTYFIVE_SOUND_ID = 25;
    private static final int TWENTYSIX_SOUND_ID = 26;
    private static final int TWENTYSEVEN_SOUND_ID = 27;
    private static final int TWENTYEIGHT_SOUND_ID = 28;
    private static final int TWENTYNINE_SOUND_ID = 29;
    private static final int THIRTY_SOUND_ID = 30;
    private static final int APPLAUSE_SOUND_ID = 100;
    private static final int MISS_SOUND_ID = 101;
    private static final int UHOH_SOUND_ID = 102;
    private static final int SOUND_PRIORITY = 1;
    private static final int MAX_STREAMS = 35;
    private SoundPool soundPool; // plays sound effects
    private int volume; // sound effect volume
    private Map<Integer, Integer> soundMap; // maps ID to soundpool
    private ArrayList<Integer> numberList;
    private LinkedHashMap<Integer,String> map;
    private int resourceId;
    private CountDownTimer timer;
    private int[] key_int;
    private String[] key;
    private String[] value;
    private int indexSearch = 0;
    private String iconName;

    // constructs a new SpotOnView
    public SpotOnView(Context context, SharedPreferences sharedPreferences,
                      RelativeLayout parentLayout)
    {
        super(context);

        // save Resources for loading external values
        resources = context.getResources();

        // save LayoutInflater
        layoutInflater = (LayoutInflater) context.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);
        numberList =
                new ArrayList<Integer>();
        map = new LinkedHashMap<Integer,String>();
        // get references to various GUI components
        relativeLayout = parentLayout;
        remainingTimeTextView = (TextView) relativeLayout.findViewById(
                R.id.remainingTimeTextView);
        levelTextView = (TextView) relativeLayout.findViewById(
                R.id.levelTextView);

        spotHandler = new Handler(); // used to add spots when game starts
    } // end SpotOnView constructor

    // store SpotOnView's width/height
    @Override
    protected void onSizeChanged(int width, int height, int oldw, int oldh)
    {
        viewWidth = width; // save the new width
        viewHeight = height; // save the new height
    } // end method onSizeChanged

    // called by the SpotOn Activity when it receives a call to onPause
    public void pause()
    {
        gamePaused = true;
        soundPool.release(); // release audio resources
        soundPool = null;
        cancelAnimations(); // cancel all outstanding animations
    } // end method pause

    // cancel animations and remove ImageViews representing spots
    private void cancelAnimations()
    {
        // cancel remaining animations
        for (Animator animator : animators)
            animator.cancel();

        // remove remaining spots from the screen
        for (ImageView view : spots)
            relativeLayout.removeView(view);

        spotHandler.removeCallbacks(addSpotRunnable);
        animators.clear();
        spots.clear();

    } // end method cancelAnimations

    // called by the SpotOn Activity when it receives a call to onResume
    public void resume(Context context)
    {
        gamePaused = false;
        initializeSoundEffects(context); // initialize app's SoundPool

        if (!dialogDisplayed)
            timeLimitForLevel = 60000;
        currentLevel = 1;
        resetGame(); // start the game
    } // end method resume

    // start a new game
    public void resetGame()
    {
        spots.clear(); // empty the List of spots
        animators.clear(); // empty the List of Animators
        numberList.clear(); // clears the number displayed on screen
        map.clear();
        animationTime = timeLimitForLevel; // init animation length
        spotsTouched = 0; // reset the number of spots touched
        indexSearch = 0;
        remainingTime = 0;
        level = currentLevel; // reset the level
        gameOver = false; // the game is not over
        allSpotsTouched = false;
        key = new String[30];
        value= new String[30];
        switch(level)
        {
            case 1:
            {
                key = this.getResources().getStringArray(R.array.level1_Id);
                value= this.getResources().getStringArray(R.array.level1_label);
            } break;

            case 2:
            {

                key = this.getResources().getStringArray(R.array.level2_Id);
                value= this.getResources().getStringArray(R.array.level2_label);
                indexSearch=10;//to add nummbers after 10
            } break;

            case 3:
            {

                key = this.getResources().getStringArray(R.array.level3_Id);
                value= this.getResources().getStringArray(R.array.level3_label);
                indexSearch=20;//to add numbers after 20
            } break;

            case 4:
            {
                String[] key_level1 = this.getResources().getStringArray(R.array.level1_Id);
                String[] key_level2 = this.getResources().getStringArray(R.array.level2_Id);
                String[] key_level3 = this.getResources().getStringArray(R.array.level3_Id);
                String[] value_level1 = this.getResources().getStringArray(R.array.level1_label);
                String[] value_level2 = this.getResources().getStringArray(R.array.level2_label);
                String[] value_level3= this.getResources().getStringArray(R.array.level3_label);
                List<String> keyList = new ArrayList(Arrays.asList(key_level1));
                List<String> valueList = new ArrayList(Arrays.asList(value_level1));
                keyList.addAll(Arrays.asList(key_level2));
                keyList.addAll(Arrays.asList(key_level3));
                valueList.addAll(Arrays.asList(value_level2));
                valueList.addAll(Arrays.asList(value_level3));
                key=keyList.toArray(key);
                value=valueList.toArray(value);          }
                break;

            default:
            {
                key = this.getResources().getStringArray(R.array.level1_Id);
                value= this.getResources().getStringArray(R.array.level1_label);
            } break;
        }
        key_int = new int[key.length];
        for (int i = 0; i < key_int.length; i++) {
            key_int[i] = Integer.parseInt(key[i]);
        }
        for (int i = 0; i < key_int.length; ++i) {
            map.put(key_int[i], value[i]);
        }
        timer=new CountDownTimer(timeLimitForLevel, 100) {//to track remaning time from 60 secs
            public void onTick(long millisUntilFinished) {
                remainingTime= millisUntilFinished / 1000;
                displayelapsedTime();
            }
            public void onFinish() {
                displayelapsedTime();
            }
        }.start();
        // add INITIAL_SPOTS new spots at SPOT_DELAY time intervals in ms
        for (int i = 1; i <= NUMBER_OF_SPOTS; ++i)
            spotHandler.postDelayed(addSpotRunnable, i * SPOT_DELAY);
    } // end method resetGame

    // create the app's SoundPool for playing game audio
    private void initializeSoundEffects(Context context)
    {
        // initialize SoundPool to play the app's 33 sound effects
        soundPool = new SoundPool.Builder()
                .setMaxStreams(MAX_STREAMS)
                .build();
        // set sound effect volume
        AudioManager manager =
                (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        volume = manager.getStreamVolume(AudioManager.STREAM_MUSIC);
        // create sound map
        soundMap = new HashMap<Integer, Integer>(); // create new HashMap
        // add each souns to the SoundPool
        soundMap.put(APPLAUSE_SOUND_ID,
                soundPool.load(context, R.raw.applause, SOUND_PRIORITY));
        soundMap.put(MISS_SOUND_ID,
                soundPool.load(context, R.raw.miss, SOUND_PRIORITY));
        soundMap.put(UHOH_SOUND_ID,
                soundPool.load(context, R.raw.uhoh, SOUND_PRIORITY));
        soundMap.put(ONE_SOUND_ID,
                soundPool.load(context, R.raw.onevoice, SOUND_PRIORITY));
        soundMap.put(TWO_SOUND_ID,
                soundPool.load(context, R.raw.twovoice, SOUND_PRIORITY));
        soundMap.put(THREE_SOUND_ID,
                soundPool.load(context, R.raw.threevoice, SOUND_PRIORITY));
        soundMap.put(FOUR_SOUND_ID,
                soundPool.load(context, R.raw.fourvoice, SOUND_PRIORITY));
        soundMap.put(FIVE_SOUND_ID,
                soundPool.load(context, R.raw.fivevoice, SOUND_PRIORITY));
        soundMap.put(SIX_SOUND_ID,
                soundPool.load(context, R.raw.sixvoice, SOUND_PRIORITY));
        soundMap.put(SEVEN_SOUND_ID,
                soundPool.load(context, R.raw.sevenvoice, SOUND_PRIORITY));
        soundMap.put(EIGHT_SOUND_ID,
                soundPool.load(context, R.raw.eightvoice, SOUND_PRIORITY));
        soundMap.put(NINE_SOUND_ID,
                soundPool.load(context, R.raw.ninevoice, SOUND_PRIORITY));
        soundMap.put(TEN_SOUND_ID,
                soundPool.load(context, R.raw.tenvoice, SOUND_PRIORITY));
        soundMap.put(ELEVEN_SOUND_ID,
                soundPool.load(context, R.raw.elevenvoice, SOUND_PRIORITY));
        soundMap.put(TWELVE_SOUND_ID,
                soundPool.load(context, R.raw.twelvevoice, SOUND_PRIORITY));
        soundMap.put(THIRTEEN_SOUND_ID,
                soundPool.load(context, R.raw.thirteenvoice, SOUND_PRIORITY));
        soundMap.put(FOURTEEN_SOUND_ID,
                soundPool.load(context, R.raw.fourteenvoice, SOUND_PRIORITY));
        soundMap.put(FIFTEEN_SOUND_ID,
                soundPool.load(context, R.raw.fifteenvoice, SOUND_PRIORITY));
        soundMap.put(SIXTEEN_SOUND_ID,
                soundPool.load(context, R.raw.sixteenvoice, SOUND_PRIORITY));
        soundMap.put(SEVENTEEN_SOUND_ID,
                soundPool.load(context, R.raw.seventeenvoice, SOUND_PRIORITY));
        soundMap.put(EIGHTEEN_SOUND_ID,
                soundPool.load(context, R.raw.eighteenvoice, SOUND_PRIORITY));
        soundMap.put(NINETEEN_SOUND_ID,
                soundPool.load(context, R.raw.nineteenvoice, SOUND_PRIORITY));
        soundMap.put(TWENTY_SOUND_ID,
                soundPool.load(context, R.raw.twentyvoice, SOUND_PRIORITY));
        soundMap.put(TWENTYONE_SOUND_ID,
                soundPool.load(context, R.raw.twentyonevoice, SOUND_PRIORITY));
        soundMap.put(TWENTYTWO_SOUND_ID,
                soundPool.load(context, R.raw.twentytwovoice, SOUND_PRIORITY));
        soundMap.put(TWENTYTHREE_SOUND_ID,
                soundPool.load(context, R.raw.twentythreevoice, SOUND_PRIORITY));
        soundMap.put(TWENTYFOUR_SOUND_ID,
                soundPool.load(context, R.raw.twentyfourvoice, SOUND_PRIORITY));
        soundMap.put(TWENTYFIVE_SOUND_ID,
                soundPool.load(context, R.raw.twentyfivevoice, SOUND_PRIORITY));
        soundMap.put(TWENTYSIX_SOUND_ID,
                soundPool.load(context, R.raw.twentysixvoice, SOUND_PRIORITY));
        soundMap.put(TWENTYSEVEN_SOUND_ID,
                soundPool.load(context, R.raw.twentysevenvoice, SOUND_PRIORITY));
        soundMap.put(TWENTYEIGHT_SOUND_ID,
                soundPool.load(context, R.raw.twentyeightvoice, SOUND_PRIORITY));
        soundMap.put(TWENTYNINE_SOUND_ID,
                soundPool.load(context, R.raw.twentyninevoice, SOUND_PRIORITY));
        soundMap.put(THIRTY_SOUND_ID,
                soundPool.load(context, R.raw.thirtyvoice, SOUND_PRIORITY));
    } // end method initializeSoundEffect

    // display scores and level
    private void displayelapsedTime()
    {
        remainingTimeTextView.setText(
                resources.getString(R.string.remaining_time) + " " + remainingTime);
        levelTextView.setText(
                resources.getString(R.string.level) + " " + level);
    }

    // Runnable used to add new spots to the game at the start
    private Runnable addSpotRunnable = new Runnable()
    {
        public void run()
        {
            addNewSpot(); // add a new spot to the game
        } // end method run
    }; // end Runnable

    // adds a new spot at a random location and starts its animation
    public void addNewSpot()
    {
        indexSearch++;
        // choose two random coordinates for the starting and ending points
        int x = random.nextInt(viewWidth - SPOT_DIAMETER);
        int y = random.nextInt(viewHeight - SPOT_DIAMETER);
        int x2 = random.nextInt(viewWidth - SPOT_DIAMETER);
        int y2 = random.nextInt(viewHeight - SPOT_DIAMETER);
        final ImageView spot =
                (ImageView) layoutInflater.inflate(R.layout.untouched, null);
        spots.add(spot); // add the new spot to our list of spots
        spot.setLayoutParams(new RelativeLayout.LayoutParams(
                SPOT_DIAMETER, SPOT_DIAMETER));
        if(level == 4)
        {
            do//we need to handle level 4 differenlt since it needs random numbers from 1 to 30
            {
                indexSearch = random.nextInt(30) + 1;
            }while(numberList.contains(indexSearch));

        }
        iconName= map.get(indexSearch);//to  match with the filename nad number
        if(!(numberList.contains(indexSearch))) {
            numberList.add(indexSearch);
            Collections.sort(numberList);
            resourceId = getResources().getIdentifier(iconName, "drawable", getContext().getPackageName());
            spot.setImageResource(resourceId);
            spot.setId(indexSearch);
            spot.setX(x); // set spot's starting x location
            spot.setY(y); // set spot's starting y location
            spot.setOnClickListener( // listens for spot being clicked
                    new OnClickListener() {
                        public void onClick(View v) {
                            if(v.getId()==numberList.get(0))
                            {
                                touchedSpot(spot); // handle touched spot
                            }
                            else
                            {

                                if (soundPool != null)
                                    soundPool.play(soundMap.get(UHOH_SOUND_ID), volume, volume,
                                            SOUND_PRIORITY, 0, 1f);

                            }

                        } // end method onClick
                    } // end OnClickListener
            ); // end call to setOnClickListener
            relativeLayout.addView(spot); // add spot to the screen

            // configure and start spot's animation
            spot.animate().x(x2).y(y2).scaleX(SCALE_X).scaleY(SCALE_Y)
                    .setDuration(animationTime).setListener(
                    new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationStart(Animator animation) {
                            animators.add(animation); // save for possible cancel
                        } // end method onAnimationStart

                        public void onAnimationEnd(Animator animation) {
                            animators.remove(animation); // animation done, remove

                            if (!gamePaused && spots.contains(spot)) // not touched
                            {
                                gameOver(spot); // lose a life
                            } // end if
                        } // end method onAnimationEnd
                    } // end AnimatorListenerAdapter
            ); // end call to setListener
        } // end of if(!(numberList.contains(randomIndex)))
    } // end addNewSpot method

    // called when the user touches the screen, but not a spot
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        // play the missed sound
        if (soundPool != null)
            soundPool.play(soundMap.get(UHOH_SOUND_ID), volume, volume,
                    SOUND_PRIORITY, 0, 1f);

        displayelapsedTime();
        return true;
    } // end method onTouchEvent

    // called when a spot is correctly touched
    private void touchedSpot(ImageView spot)
    {
        // play the hit sounds
        if (soundPool != null)
            soundPool.play(soundMap.get(numberList.get(0)), volume, volume,
                    SOUND_PRIORITY, 0, 1f);

        relativeLayout.removeView(spot); // remove touched spot from screen
        spots.remove(spot); // remove old spot from list
        numberList.remove(0);
        if(numberList.size()==0) {//to check to proceed to next level
            allSpotsTouched=true; // sets only if all 10 numbers are identified corectly
        }
        // increment level if player touched 10 spots in the current level
        if (allSpotsTouched==true && remainingTime!=0)
        {
            ++level; // increment the level
            animationTime *= 0.95; // make game 5% faster than prior level
            switch(level)
            {
                case 2:
                {
                    timer.cancel();
                    timeLimitForLevel=55000;
                    currentLevel = 2;
                    resetGame();
                } break;
                case 3:
                {
                    timer.cancel();
                    timeLimitForLevel=50000;
                    currentLevel = 3;
                    resetGame();
                } break;
                case 4:
                {
                    timer.cancel();
                    timeLimitForLevel=45000;
                    currentLevel = 4;
                    resetGame();
                } break;
                case 5:
                {
                    gameOver(spot);

                } break;
                default:
                {
                    timer.cancel();
                    gameOver = true;
                    gameOver(spot);
                } break;
            }

        } // end if
        displayelapsedTime();
    } // end method touchedSpot

    // called when a spot finishes its animation without being touched
    public void gameOver(ImageView spot)
    {
        if (gameOver) // if the game is already over, exit
            return;

        if(level == MAX_LEVEL && remainingTime!=0)
        {
            // play the applause sounds
            if (soundPool != null)
                soundPool.play(soundMap.get(APPLAUSE_SOUND_ID), volume, volume,
                        SOUND_PRIORITY, 0, 1f);
            gameOver = true; // the game is over
            cancelAnimations();
            timer.cancel();
            // display dialog
            Builder dialogBuilder = new AlertDialog.Builder(getContext());
            dialogBuilder.setTitle(R.string.game_completed);
            dialogBuilder.setPositiveButton(R.string.reset_game,
                    new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int which)
                        {
                            displayelapsedTime();//
                            dialogDisplayed = false;
                            timeLimitForLevel = 60000;
                            currentLevel = 1;
                            resetGame(); // start a new game
                        } // end method onClick
                    } // end DialogInterface
            ); // end call to dialogBuilder.setPositiveButton
            dialogDisplayed = true;
            dialogBuilder.show();
        }

        // if the game has been lost
        if (remainingTime == 0)
        {
            gameOver = true; // the game is over
            cancelAnimations();

            // display dialog
            Builder dialogBuilder = new AlertDialog.Builder(getContext());
            dialogBuilder.setTitle(R.string.game_over);
            dialogBuilder.setPositiveButton(R.string.reset_game,
                    new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int which)
                        {
                            displayelapsedTime(); // ensure that score is up to date
                            dialogDisplayed = false;
                            timeLimitForLevel = 60000;
                            currentLevel = 1;
                            resetGame(); // start a new game
                        } // end method onClick
                    } // end DialogInterface
            ); // end call to dialogBuilder.setPositiveButton
            dialogDisplayed = true;
            dialogBuilder.show(); // display the reset game dialog
        } // end if
    } // end method missedSpot
} // end class SpotOnView



